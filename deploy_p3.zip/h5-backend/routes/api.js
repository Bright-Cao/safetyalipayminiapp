const express = require('express');
const router = express.Router();

const authMiddleware = require('../middleware/authMiddleware');

const authController = require('../controllers/auth');
const guardianController = require('../controllers/guardian');
const examController = require('../controllers/exam');
const trainingController = require('../controllers/training');
const applicationController = require('../controllers/application');
const exportController = require('../controllers/export');
const workshopAdminController = require('../controllers/workshop_admin');
const userManageController = require('../controllers/user_manage');
const videoRoutes = require('./video');

// Auth routes (Open)
router.post('/login', authController.login);

// Guardian routes (Open - assuming it's a public inquiry)
router.post('/checkGuardian', guardianController.checkGuardian);

// Video Routes (from video.js)
// We merge them here or keep videoRoutes as a separate router module that we consume.
router.use('/video', videoRoutes);

// Protected Routes below (requires authentication logincards/etc)
router.use(authMiddleware);

// Application routes
router.post('/getMyApplications', applicationController.getMyApplications);
router.post('/submitApplication', applicationController.submitApplication);
router.post('/getAllApplications', applicationController.getAllApplications);

// Admin Data Exports
router.post('/exportData', exportController.exportData);

// Workshop Admin Routes
router.post('/workshop/getApplications', workshopAdminController.getWorkshopApplications);
router.post('/workshop/approveInterview', workshopAdminController.approveWorkshopInterview);

// User Management (super_admin only)
router.post('/admin/getAllUsers', userManageController.getAllUsers);
router.post('/admin/updateUserRole', userManageController.updateUserRole);

// Exam & Practice routes
router.post('/getPracticeQuestions', examController.getPracticeQuestions);
router.post('/getExamQuestions', examController.getExamQuestions);
router.post('/submitExam', examController.submitExam);

// Training routes
router.post('/updateVideoProgress', trainingController.updateVideoProgress);

// TODO: submitPracticeAnswers, if needed

module.exports = router;
