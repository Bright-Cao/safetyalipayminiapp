const { Application, User } = require('../models');

// 获取当前车间的待审批申请列表
exports.getWorkshopApplications = async (req, res) => {
  const caller = req.user;
  if (!caller) return res.json({ success: false, message: '未授权访问' });

  try {
    const user = await User.findById(caller.dbId).lean();
    if (!user) return res.json({ success: false, message: '当前用户不存在' });

    if (!['workshop_leader', 'safety_admin', 'super_admin'].includes(user.role)) {
      return res.json({ success: false, message: '无权限访问' });
    }

    // 车间主任只看自己车间的申请；安全科和超管能看所有
    const query = { status: 'pending_workshop_interview' };
    if (user.role === 'workshop_leader' && user.workshop_name) {
      query.workshop_name = user.workshop_name;
    }

    const applications = await Application.find(query).sort({ update_time: -1 }).lean();
    return res.json({ success: true, data: applications });
  } catch (error) {
    console.error('获取车间申请失败:', error);
    return res.json({ success: false, message: '获取失败: ' + error.message });
  }
};

// 车间领导面试打分并放行
exports.approveWorkshopInterview = async (req, res) => {
  const caller = req.user;
  if (!caller) return res.json({ success: false, message: '未授权访问' });

  const { applicationId, interviewScore, interviewNotes, passed } = req.body;

  try {
    const user = await User.findById(caller.dbId).lean();
    if (!user || !['workshop_leader', 'safety_admin', 'super_admin'].includes(user.role)) {
      return res.json({ success: false, message: '权限不足' });
    }

    const app = await Application.findById(applicationId);
    if (!app) return res.json({ success: false, message: '申请记录不存在' });

    if (passed) {
      if (app.category === 'guardian') {
        // 监护人通过面试后，进入培训阶段
        app.status = 'pending_training';
      } else {
        // 班组长等免考角色，面试通过即发证
        app.status = 'qualified';
        app.valid_until = new Date(Date.now() + 365 * 24 * 60 * 60 * 1000);

        // 更新用户首次发证时间
        const appUser = await User.findOne({ phone: app.phone });
        if (appUser && !appUser.first_cert_date) {
          appUser.first_cert_date = new Date();
          await appUser.save();
        }
      }
    } else {
      app.status = 'rejected';
    }

    app.interview_score = interviewScore;
    app.interview_notes = interviewNotes;
    app.update_time = new Date();
    await app.save();

    return res.json({ success: true, message: '面试结果已保存' });
  } catch (error) {
    console.error('保存面试结果失败:', error);
    return res.json({ success: false, message: '审批失败: ' + error.message });
  }
};
