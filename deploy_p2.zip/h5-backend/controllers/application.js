const { Application } = require('../models');

exports.getMyApplications = async (req, res) => {
  const userId = req.user && req.user.userId;
  if (!userId) return res.json({ success: false, message: '未授权访问' });

  try {
    const applications = await Application.find({ _openid: userId }).sort({ create_time: -1 }).lean();
    return res.json({ success: true, data: applications });
  } catch (error) {
    console.error('获取申请记录失败:', error);
    return res.json({ success: false, message: '获取失败: ' + error.message });
  }
};

exports.submitApplication = async (req, res) => {
  const userId = req.user && req.user.userId;
  if (!userId) return res.json({ success: false, message: '未授权访问' });

  const appData = req.body;
  
  // Decide routing based on category
  let defaultStatus = 'pending_workshop_interview'; 
  if (appData.category === 'safety_principal' || appData.category === 'safety_officer') {
    defaultStatus = 'pending_admin_interview';
  }

  try {
    const newApplication = new Application({
      ...appData,
      _openid: userId,
      status: defaultStatus,
      create_time: new Date(),
      update_time: new Date()
    });

    const savedApp = await newApplication.save();

    return res.json({ success: true, data: savedApp });

  } catch (error) {
    console.error('提交申请失败:', error);
    return res.json({ success: false, message: '提交失败: ' + error.message });
  }
};

exports.getAllApplications = async (req, res) => {
  // admin only logic usually
  const { workshop } = req.body;
  try {
    const query = {};
    if (workshop) query.workshop = workshop;

    const applications = await Application.find(query).sort({ create_time: -1 }).limit(100).lean();
    return res.json({ success: true, data: applications });
  } catch (error) {
    return res.json({ success: false, message: '获取失败: ' + error.message });
  }
};
