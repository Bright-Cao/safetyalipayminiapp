const { Application, User } = require('../models');

// 获取当前车间的所有申请（待车间领导面试）
exports.getWorkshopApplications = async (req, res) => {
  const userId = req.user && req.user.userId;
  if (!userId) return res.json({ success: false, message: '未授权访问' });

  try {
    const user = await User.findOne({ _openid: userId }).lean();
    if (user.role !== 'workshop_leader' && user.role !== 'safety_admin') {
      return res.json({ success: false, message: '无权限访问' });
    }

    // 车间领导只能看自己的车间，安全科能看所有车间但主要是查阅
    const query = { status: 'pending_workshop_interview' };
    if (user.role === 'workshop_leader') {
      query.workshop = user.workshop_name;
    }

    const applications = await Application.find(query).sort({ create_time: -1 }).lean();
    return res.json({ success: true, data: applications });
  } catch (error) {
    console.error('获取车间申请失败:', error);
    return res.json({ success: false, message: '获取失败: ' + error.message });
  }
};

// 车间领导面试打分并放行
exports.approveWorkshopInterview = async (req, res) => {
  const userId = req.user && req.user.userId;
  if (!userId) return res.json({ success: false, message: '未授权访问' });

  const { applicationId, interviewScore, interviewNotes, passed } = req.body;

  try {
    const app = await Application.findById(applicationId);
    if (!app) return res.json({ success: false, message: '申请记录不存在' });

    // 如果通过面试
    if (passed) {
      if (app.category === 'guardian') {
        app.status = 'pending_training'; // 监护人接下来要去培训和考试
      } else {
        app.status = 'qualified'; // 班组长直接发证
        app.valid_until = new Date(Date.now() + 365 * 24 * 60 * 60 * 1000); // 一年有效期
        
        // 此处可以更新User表的first_cert_date等业务逻辑
        const user = await User.findOne({ _openid: app._openid });
        if (user && !user.first_cert_date) {
            user.first_cert_date = new Date();
            await user.save();
        }
      }
    } else {
      app.status = 'rejected';
    }

    app.interview_score = interviewScore;
    app.interview_notes = interviewNotes;
    app.update_time = new Date();
    
    await app.save();

    return res.json({ success: true, message: '面试结果已保存', data: app });
  } catch (error) {
    console.error('保存面试结果失败:', error);
    return res.json({ success: false, message: '审批失败: ' + error.message });
  }
};
