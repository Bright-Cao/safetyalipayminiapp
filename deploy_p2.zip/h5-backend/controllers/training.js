const { TrainingRecord } = require('../models');

exports.updateVideoProgress = async (req, res) => {
  const { recordId, videoId, progress, watchTime, lastTime } = req.body;
  const userId = req.user && req.user.userId;

  if (!userId) {
    return res.json({ success: false, message: '未授权访问' });
  }

  try {
    let trainingRecord = recordId 
      ? await TrainingRecord.findById(recordId)
      : await TrainingRecord.findOne({ _openid: userId }).sort({ update_time: -1 });

    if (!trainingRecord) {
      // If none exists, we can choose to create one, or return error depending on the app logic.
      // Usually, when user logs in and goes to training, a record might be pre-created.
      // Here we assume we create a new one if it doesn't exist, linked to user.
      trainingRecord = new TrainingRecord({
        _openid: userId,
        video_progress: new Map(),
        update_time: new Date()
      });
    }

    const currentProgress = trainingRecord.video_progress.get(videoId) || { progress: 0, watch_time: 0, completed: false };

    // 防止观看时间异常增长
    const timeDiff = watchTime - currentProgress.watch_time;
    if (timeDiff > 15) {
      console.warn('检测到异常观看时间:', { diff: timeDiff });
      // In practice we may reject this or scale it down. Here as original logic:
      return res.json({ success: false, message: '检测到异常操作' });
    }

    const completed = progress >= 90;
    
    const newProgressObj = {
      progress: Math.min(Math.max(progress, currentProgress.progress), 100),
      watch_time: watchTime,
      last_time: lastTime || currentProgress.last_time || 0,
      completed: completed,
      last_update: new Date()
    };

    if (completed && !currentProgress.completed) {
      newProgressObj.completed_time = new Date();
    }

    trainingRecord.video_progress.set(videoId, newProgressObj);
    trainingRecord.update_time = new Date();

    await trainingRecord.save();

    return res.json({ success: true });
  } catch (error) {
    console.error('更新进度失败:', error);
    return res.json({ success: false, message: '更新失败: ' + error.message });
  }
};
