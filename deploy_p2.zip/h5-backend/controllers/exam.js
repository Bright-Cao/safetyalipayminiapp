const { ExamQuestion, ExamSetting, ExamRecord, Application } = require('../models');

// 获取练题题目 (对应 getPracticeQuestions)
exports.getPracticeQuestions = async (req, res) => {
  const { mode } = req.body; // 'recitation' | 'mock'
  
  try {
    const query = { status: 'active' };
    const questionsRes = await ExamQuestion.find(query).limit(500).lean();

    let questions = questionsRes.map(q => ({
      _id: q._id,
      type: q.type,
      question: q.question,
      options: q.options || [],
      correct_answer: q.correct_answer,
      explanation: q.explanation || '',
    }));

    // 模拟考试模式：随机打乱顺序并限制数量
    if (mode === 'mock') {
      for (let i = questions.length - 1; i > 0; i--) {
        const j = Math.floor(Math.random() * (i + 1));
        [questions[i], questions[j]] = [questions[j], questions[i]];
      }
      questions = questions.slice(0, 50); // 模拟考试取50题
    }

    return res.json({
      success: true,
      data: questions,
      total: questions.length
    });
  } catch (error) {
    console.error('获取练习题失败:', error);
    return res.json({ success: false, message: '获取题目失败: ' + error.message });
  }
};

// 获取考试题目 (对应 getExamQuestions)
exports.getExamQuestions = async (req, res) => {
  try {
    let config = { single: 20, multiple: 10, judge: 20 };
    try {
      const settingsRes = await ExamSetting.findById('global_config');
      if (settingsRes) {
        if (settingsRes.single) config.single = settingsRes.single.count || 20;
        if (settingsRes.multiple) config.multiple = settingsRes.multiple.count || 10;
        if (settingsRes.judge) config.judge = settingsRes.judge.count || 20;
      }
    } catch (e) {
      console.warn('读取考试配置失败，使用默认值');
    }

    const fetchRandom = async (type, count) => {
      let all = await ExamQuestion.find({ type, status: 'active' }).limit(500).lean();
      
      for (let i = all.length - 1; i > 0; i--) {
        const j = Math.floor(Math.random() * (i + 1));
        [all[i], all[j]] = [all[j], all[i]];
      }
      
      return all.slice(0, count).map(q => ({
        _id: q._id,
        type: q.type,
        question: q.question,
        options: q.options || [],
        // 不暴露 correct_answer 和 explanation
      }));
    };

    const [singles, multiples, judges] = await Promise.all([
      fetchRandom('single', config.single),
      fetchRandom('multiple', config.multiple),
      fetchRandom('judge', config.judge),
    ]);

    const questions = [...singles, ...multiples, ...judges];

    return res.json({
      success: true,
      data: questions,
      total: questions.length
    });
  } catch (error) {
    console.error('获取考试题目失败:', error);
    return res.json({ success: false, message: '获取题目失败: ' + error.message });
  }
};

// 提交考试 (对应 submitExam)
exports.submitExam = async (req, res) => {
  const { application_id, answers, time_used } = req.body;
  const userId = req.user && req.user.userId; // 假定有 auth middleware

  if (!userId) {
    return res.json({ success: false, message: '未授权访问' });
  }

  try {
    // 0. 获取评分配置
    let scoreConfig = { single: 2, multiple: 4, judge: 2 };
    try {
      const settingsRes = await ExamSetting.findById('global_config');
      if (settingsRes) {
        if (settingsRes.single) scoreConfig.single = settingsRes.single.score;
        if (settingsRes.multiple) scoreConfig.multiple = settingsRes.multiple.score;
        if (settingsRes.judge) scoreConfig.judge = settingsRes.judge.score;
      }
    } catch (e) {
      console.warn('读取评分配置失败，用默认值', e);
    }

    // 1. 获取题库中对应的正确答案
    const questionIds = (answers || []).map(a => a.question_id);
    const questionsRes = await ExamQuestion.find({ _id: { $in: questionIds } });
    const questionsMap = {};
    questionsRes.forEach(q => { questionsMap[q._id.toString()] = q; });

    // 2. 评分
    let totalScore = 0;
    let correctCount = 0;
    const detailedAnswers = (answers || []).map(answer => {
      const question = questionsMap[answer.question_id];
      if (!question) return null;

      const typeScore = scoreConfig[question.type] || 0;

      // 标准化数据库答案
      let dbAnsRaw = question.correct_answer;
      let dbAnsList = [];
      if (Array.isArray(dbAnsRaw)) {
        dbAnsList = dbAnsRaw;
      } else if (dbAnsRaw !== undefined && dbAnsRaw !== null) {
        const s = String(dbAnsRaw).trim();
        dbAnsList = s.includes(',') ? s.split(',') : [s];
      }

      const normalizedDbList = dbAnsList.map(item => {
        let s = String(item).trim();
        if (s.toLowerCase() === 'true') s = '正确';
        if (s.toLowerCase() === 'false') s = '错误';
        if (/^[A-Z]$/.test(s)) {
          const idx = s.charCodeAt(0) - 65;
          if (question.options && question.options[idx]) return String(question.options[idx]).trim();
        }
        return s;
      });
      const correctVal = normalizedDbList.sort().join(',');

      // 标准化用户答案
      let userVal = '';
      if (Array.isArray(answer.answer)) {
        userVal = answer.answer.map(a => String(a).trim()).sort().join(',');
      } else {
        userVal = String(answer.answer || '').trim();
        if (userVal.toLowerCase() === 'true') userVal = '正确';
        if (userVal.toLowerCase() === 'false') userVal = '错误';
      }

      const isCorrect = userVal === correctVal;
      const score = isCorrect ? typeScore : 0;
      if (isCorrect) correctCount++;
      totalScore += score;

      return {
        question_id: answer.question_id,
        user_answer: answer.answer,
        correct_answer: correctVal,
        explanation: question.explanation || '',
        is_correct: isCorrect,
        score: score
      };
    }).filter(Boolean);

    const passed = totalScore >= 80;

    // 3. 保存考试记录
    const examRecord = new ExamRecord({
      application_id,
      _openid: userId,
      answers: detailedAnswers,
      total_score: totalScore,
      correct_count: correctCount,
      total_count: answers.length,
      time_used,
      passed,
      exam_time: new Date()
    });
    
    await examRecord.save();

    return res.json({
      success: true,
      data: {
        score: totalScore,
        correct_count: correctCount,
        total_count: answers.length,
        passed,
        detailed_answers: detailedAnswers
      }
    });
  } catch (error) {
    console.error('提交考试失败:', error);
    return res.json({ success: false, message: '提交失败: ' + error.message });
  }
};
