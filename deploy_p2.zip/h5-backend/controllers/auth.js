const jwt = require('jsonwebtoken');
const { User } = require('../models');

const JWT_SECRET = process.env.JWT_SECRET || 'fallback-secret-key';

exports.login = async (req, res) => {
  const { phoneNumber, role, workshop_id, workshop_name } = req.body;

  try {
    if (!phoneNumber || phoneNumber.length < 11) {
      return res.json({ success: false, message: '请输入正确的手机号' });
    }

    let userInfo;
    let user = await User.findOne({ phone: phoneNumber });

    if (user) {
      if (user.status !== 'active') {
        return res.json({ success: false, message: '账号已被锁定，请联系安全科' });
      }

      // 角色切换逻辑
      if (user.role !== role) {
        if (role === 'applicant' || user.role === 'safety_admin') {
          user.role = role;
          if (workshop_id || workshop_name) {
            user.workshop_id = workshop_id;
            user.workshop_name = workshop_name;
          }
        } else {
          return res.json({ success: false, message: '权限不足，无法以该身份登录' });
        }
      }

      user.lastLoginTime = new Date();
      await user.save();
      userInfo = user;
    } else {
      // 仅申请人可自助注册
      if (role !== 'applicant') {
        return res.json({ success: false, message: '该手机号未授权，请联系安全科添加账号' });
      }

      // 自动注册
      const userId = 'uid_' + Date.now(); // Fallback openid
      user = new User({
        _openid: userId,
        phone: phoneNumber,
        role: 'applicant',
        name: '用户' + phoneNumber.slice(-4),
        status: 'active',
        workshop_id: workshop_id || '',
        workshop_name: workshop_name || '',
        createTime: new Date(),
        lastLoginTime: new Date()
      });

      await user.save();
      userInfo = user;
    }

    // 生成 JWT Token，有效期 7 天
    const token = jwt.sign(
      { userId: userInfo._openid, phone: userInfo.phone, role: userInfo.role },
      JWT_SECRET,
      { expiresIn: '7d' }
    );

    return res.json({
      success: true,
      data: { userInfo, openid: userInfo._openid, token }
    });
  } catch (error) {
    console.error('登录失败:', error);
    return res.json({ success: false, message: '系统异常: ' + error.message });
  }
};
